# Blog to Social Posts


A small project using Cheerio.js that scrapes sentences from a blog and uploads them into a .csv file.

Project hosted on [Heroku](https://nameless-stream-74310.herokuapp.com/)