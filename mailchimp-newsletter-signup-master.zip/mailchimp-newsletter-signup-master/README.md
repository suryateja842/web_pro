# Newsletter Signup with Mailchimp.

Be sure to use 'npm install' to download dependencies. 
