# javascript30-css-and-js-clock
Project 2 from Wes Bos's Javascript30
